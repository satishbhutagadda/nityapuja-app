import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-multiple-choice',
  templateUrl: './multiple-choice.page.html',
  styleUrls: ['./multiple-choice.page.scss'],
})
export class MultipleChoicePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
