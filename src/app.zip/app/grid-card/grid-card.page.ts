import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grid-card',
  templateUrl: './grid-card.page.html',
  styleUrls: ['./grid-card.page.scss'],
})
export class GridCardPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
